package org.example;

public enum BotState {
    UZB,
    RUS,
    START,
    MAIN,
    ABOUT, PHONE_NUMBER,
}